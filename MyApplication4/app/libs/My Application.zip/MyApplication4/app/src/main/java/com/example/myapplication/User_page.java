package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class User_page extends Activity implements View.OnClickListener {


    private Button loginBtn;
    private Button cancelBtn;
    private TextView textview111;
    private Button mMain;
    private Button hHelp;
    private Button uUser;
    @Override
    protected void onCreate(Bundle arg0) {
        // TODO Auto-generated method stub
        super.onCreate(arg0);
        setContentView(R.layout.activity_user);
        loginBtn = (Button) findViewById(R.id.lLogin);
        cancelBtn = (Button) findViewById(R.id.cCancel);
        textview111 = (TextView) findViewById(R.id.tvAccount);
        mMain = (Button) findViewById(R.id.m_Main);
        hHelp = (Button) findViewById(R.id.h_Help);
        uUser = (Button) findViewById(R.id.u_User);
        mMain.setOnClickListener(this);
        hHelp.setOnClickListener(this);
        uUser.setOnClickListener(this);
        loginBtn.setOnClickListener(this);
        cancelBtn.setOnClickListener(this);
//        LinearLayout mainLinerLayout = (LinearLayout) this.findViewById(R.id.tvAccount);
//        TextView textview=new TextView(this);
        //init();
        String userAccount = UserPreference.read(KeyConstance.IS_USER_ACCOUNT, null);
        if(userAccount == null)
        {
        	textview111.setText("无登录账号");
        	
        }
        else
        {
        	textview111.setText(userAccount);
        	
        }
    }

    /**
     * 初始化数据
     */
    
    @Override
    public void onClick(View v) {
        if (v == loginBtn) {
        	Intent intent = new Intent();
            intent.setClass(User_page.this, LoginActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.slide_in_left,
                    android.R.anim.slide_out_right);
            finish();
            
        }
        if (v == cancelBtn) {
        	SharedPreferences sp;

	        sp = getSharedPreferences("user_preference",0);
	        sp.edit().clear().commit();
	        Intent intent = new Intent();
            intent.setClass(User_page.this, User_page.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.slide_in_left,
                    android.R.anim.slide_out_right);
            finish();

           
        }
        if (v == mMain) {

            //on attachment icon click
        	Intent intent = new Intent();
            intent.setClass(User_page.this, MainActivity.class);
            startActivity(intent);
        }
        if (v == uUser) {

            //on attachment icon click
        	Intent intent = new Intent();
            intent.setClass(User_page.this, User_page.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.slide_in_left,
                    android.R.anim.slide_out_right);
            finish();
        }
        if (v == hHelp) {

            //on attachment icon click
        	Intent intent = new Intent();
            intent.setClass(User_page.this, Help_page.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.slide_in_left,
                    android.R.anim.slide_out_right);
            finish();
        }
       

    }

    

    private void init() {
        
        //点击登录按钮
        loginBtn.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View v) {
            	
            	Intent intent = new Intent();
                intent.setClass(User_page.this, LoginActivity.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.slide_in_left,
                        android.R.anim.slide_out_right);
                finish();
            	
            	
                
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	SharedPreferences sp;

		        sp = getSharedPreferences("user_preference",0);
		        sp.edit().clear().commit();
	          
            }
        });
    }


}
